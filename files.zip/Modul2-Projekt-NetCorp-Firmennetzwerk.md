---
tags: [ccna, modul2-network-access, projekt, firmennetzwerk, portfolio]
modul: "2 - Network Access (Praxisprojekt)"
thema: "Firmennetzwerk NetCorp GmbH - VLANs, Trunking, Inter-VLAN-Routing, Internet-Uplink"
---

# 🏢 Praxisprojekt: Firmennetzwerk "NetCorp GmbH"

> Zusammenfassendes Projekt nach Modul 2, Lektion 1-3: VLAN-Grundlagen, Trunking, Inter-VLAN-Routing — kombiniert in einer realistischen 4-Abteilungen-Firmentopologie mit Internetanbindung.

## Design-Prinzip

Two-Tier-Architektur: Access Layer (2 Switches, je 2 Abteilungen) → Core Switch (Sammelpunkt) → Edge Router (Inter-VLAN-Routing + Internet-Uplink zu simuliertem ISP).

## Abteilungen

| Abteilung | VLAN-ID | Subnetz | Gateway |
|---|---|---|---|
| Sales | 10 | 192.168.10.0/24 | 192.168.10.1 |
| IT | 20 | 192.168.20.0/24 | 192.168.20.1 |
| HR | 30 | 192.168.30.0/24 | 192.168.30.1 |
| Accounting | 40 | 192.168.40.0/24 | 192.168.40.1 |

## Geräteliste

| Gerät | Rolle |
|---|---|
| ISP | Simuliert Internet (Loopback 8.8.8.8/32) |
| R1 | Edge-Router: Inter-VLAN-Routing (Router-on-a-Stick) + Internet-Uplink |
| SW-CORE | Core-Switch: verbindet SW-A, SW-B und R1 |
| SW-A | Access-Switch: Sales (VLAN10) + IT (VLAN20) |
| SW-B | Access-Switch: HR (VLAN30) + Accounting (VLAN40) |
| PC1-PC8 | 2 Endgeräte pro Abteilung |

## Topologie

```
[ISP] ── (203.0.113.0/30) ── [R1]
                                │ Gi0/0 TRUNK
                            [SW-CORE]
                            /        \
                       TRUNK          TRUNK
                        /                \
                    [SW-A]              [SW-B]
                   /      \            /      \
              Access    Access    Access    Access
              PC1,2      PC3,4     PC5,6     PC7,8
             (VLAN10)  (VLAN20)  (VLAN30)  (VLAN40)
```

WAN-Link R1↔ISP: 203.0.113.0/30 (R1=.2, ISP=.1)

---

## Konfiguration — Kernbefehle je Gerät

### SW-A / SW-B (Access Switches)
```
vlan <id>
name <Abteilung>
exit
interface fastEthernet 0/X
switchport mode access
switchport access vlan <id>
exit
```
Uplink zum Core:
```
interface gigabitEthernet 0/1
switchport mode trunk
switchport trunk native vlan 999
switchport nonegotiate
```

### SW-CORE
Alle 4 VLANs + VLAN 999 (Native) erstellen (auch ohne direkt angeschlossene PCs — notwendig, damit Trunk-Traffic nicht verworfen wird). Trunk-Ports zu SW-A, SW-B und R1, jeweils mit `switchport mode trunk`, `switchport trunk native vlan 999`, `switchport nonegotiate`.

### R1 (Edge-Router)
Trunk-Interface (Stick) aktivieren:
```
interface gigabitEthernet 0/0
no shutdown
```
Subinterfaces pro VLAN:
```
interface gigabitEthernet 0/0.10
encapsulation dot1q 10
ip address 192.168.10.1 255.255.255.0
```
(analog für .20, .30, .40)

WAN-Interface zum ISP:
```
interface gigabitEthernet 0/1
ip address 203.0.113.2 255.255.255.252
no shutdown
```

Default-Route (Vorgriff Modul 3):
```
ip route 0.0.0.0 0.0.0.0 203.0.113.1
```

### ISP-Router
```
interface gigabitEthernet 0/0
ip address 203.0.113.1 255.255.255.252
no shutdown

interface loopback 0
ip address 8.8.8.8 255.255.255.255

ip route 192.168.10.0 255.255.255.0 203.0.113.2
ip route 192.168.20.0 255.255.255.0 203.0.113.2
ip route 192.168.30.0 255.255.255.0 203.0.113.2
ip route 192.168.40.0 255.255.255.0 203.0.113.2
```

---

## ✅ Erfolgreicher Testplan

| Test | Von → Nach | Ergebnis |
|---|---|---|
| Intra-VLAN | PC1 → PC2 (Sales) | ✅ |
| Inter-VLAN | PC1 → PC3 (Sales→IT) | ✅ |
| Inter-VLAN | PC1 → PC5 (Sales→HR) | ✅ |
| Inter-VLAN | PC3 → PC7 (IT→Accounting) | ✅ |
| Internet-Simulation | PC1 → 8.8.8.8 | ✅ |
| WAN-Link | R1 → ISP (203.0.113.1) | ✅ |

---

## 🐛 Reales Troubleshooting aus diesem Projekt (dokumentiert!)

**Problem:** `ping 8.8.8.8` von PC1 schlug fehl mit "Destination host unreachable" von R1. `ping 203.0.113.1` von R1 aus: 0% Erfolg.

**Diagnose:**
1. `show ip interface brief` auf R1: Gi0/1 zeigte `Status=up, Protocol=down` → physisches Problem, nicht Konfigurationsproblem
2. `show ip interface brief` auf ISP: Gi0/1 (konfigurierter Port) zeigte `down/down`, Gi0/0 (unkonfigurierter Port) zeigte `administratively down`
3. Physical-Ansicht bestätigte: Kabel steckte tatsächlich an Gi0/0, nicht Gi0/1 wie ursprünglich angenommen

**Lösung:** Kabel auf den korrekten Port (Gi0/1) umgesteckt, `hostname ISP` nachträglich gesetzt (Router zeigte noch Default-Namen "Router2").

**Lernpunkt:** `Status=up` + `Protocol=down` deutet fast immer auf ein **physisches/Layer-1-Problem** hin (falscher Port, falsches Kabel, Gegenseite down) — nicht auf einen Konfigurationsfehler der IP-Adresse selbst. Immer zuerst die Physical-Ansicht prüfen, wenn Protocol down bleibt, obwohl die Konfiguration korrekt aussieht.

---

## 🔗 Verlinkung
- Basiert auf: [[Modul2-Lektion1-VLAN-Grundlagen]], [[Modul2-Lektion2-Trunking-802.1Q]], [[Modul2-Lektion3-Inter-VLAN-Routing]]
- Modul-Übersicht: [[Modul2-Network-Access]]
